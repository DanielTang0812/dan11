package org.generation.webproject.repository;

import org.generation.webproject.repository.entity.Item;
import org.springframework.data.repository.CrudRepository;

public interface ItemRepository extends CrudRepository<Item, Integer>
{
}

