
//To create an instance of ProductsController Class
const productsControl = new ProductsController();

function loadData()
{
    productsControl.displayItem();
}
loadData();

