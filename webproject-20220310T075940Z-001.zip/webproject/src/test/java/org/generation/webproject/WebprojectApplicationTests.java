package org.generation.webproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
